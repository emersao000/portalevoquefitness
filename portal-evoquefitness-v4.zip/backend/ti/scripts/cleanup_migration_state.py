"""Limpa estados de migração anteriores que possam ter falhado"""
def cleanup_migration_state():
    # Sem estado para limpar nesta versão
    pass
