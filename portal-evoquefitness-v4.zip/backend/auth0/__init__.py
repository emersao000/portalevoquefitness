"""Auth0 authentication module"""
